
%% file to save results of Dynare estimation to .csv
% Benedikt Kolb, 12/12/2014

names=fieldnames(oo_.posterior_mean.parameters);

prio_dist=zeros(length(names),1);
prio_mean=zeros(length(names),1);
post_mean=zeros(length(names),1);
prio_stdv=zeros(length(names),1);
post_stdv=zeros(length(names),1);
post_05qt=zeros(length(names),1);
post_95qt=zeros(length(names),1);

for nn=1:size(names,1)
    
    prio_dist(nn,1)=bayestopt_.pshape(nn);
    prio_mean(nn,1)=oo_.prior.mean(nn);
    post_mean(nn,1)=eval(strcat('oo_.posterior_mean.parameters.',char(names(nn))));
    prio_stdv(nn,1)=sqrt(oo_.prior.variance(nn));
    post_stdv(nn,1)=eval(strcat('oo_.posterior_std.parameters.',char(names(nn))));
    post_05qt(nn,1)=eval(strcat('oo_.posterior_hpdinf.parameters.',char(names(nn))));
    post_95qt(nn,1)=eval(strcat('oo_.posterior_hpdsup.parameters.',char(names(nn))));

end

csvwrite('GNSS_estim_out.csv',[prio_dist,prio_mean,post_mean,prio_stdv,post_stdv,post_05qt,post_95qt]);

